"""Milesian isopsephy and the 27-opening control.

Edition scored: SBL Greek New Testament (Holmes 2010).
Iota subscript (ypogegrammeni) counts as 10. Editorial sigla and accents
are stripped. Movable nu is kept when the edition prints it.
"""

from __future__ import annotations

import math
import re
import unicodedata
import zipfile
from pathlib import Path

MILESIAN = {
    "α": 1, "β": 2, "γ": 3, "δ": 4, "ε": 5, "ζ": 7, "η": 8, "θ": 9,
    "ι": 10, "κ": 20, "λ": 30, "μ": 40, "ν": 50, "ξ": 60, "ο": 70,
    "π": 80, "ρ": 100, "σ": 200, "ς": 200, "τ": 300, "υ": 400,
    "φ": 500, "χ": 600, "ψ": 700, "ω": 800,
}

BOOKS = [
    "Matt", "Mark", "Luke", "John", "Acts", "Rom", "1Cor", "2Cor",
    "Gal", "Eph", "Phil", "Col", "1Thess", "2Thess", "1Tim", "2Tim",
    "Titus", "Phlm", "Heb", "Jas", "1Pet", "2Pet", "1John", "2John",
    "3John", "Jude", "Rev",
]

SIGLA = re.compile(r"[⸀-⸟\[\]()·.,;:!?«»“”\"'—\-]")


def score(text: str, count_jot: bool = True) -> tuple[int, int, int]:
    """Return (total, jot_count, letter_count)."""
    total = jots = letters = 0
    for ch in text:
        decomp = unicodedata.normalize("NFD", ch)
        has_sub = "\u0345" in decomp
        base = "".join(c for c in decomp if not unicodedata.category(c).startswith("M"))
        base = base.lower().replace("ς", "σ")
        if base in MILESIAN:
            total += MILESIAN[base]
            letters += 1
        if has_sub:
            jots += 1
            if count_jot:
                total += 10
                letters += 1
    return total, jots, letters


def word_count(text: str) -> int:
    cleaned = SIGLA.sub(" ", text)
    return sum(1 for w in cleaned.split() if any(c.isalpha() for c in w))


def is_triangular(n: int) -> tuple[bool, int]:
    disc = 8 * n + 1
    root = int(math.isqrt(disc))
    if root * root != disc or root % 2 == 0:
        return False, 0
    return True, (root - 1) // 2


def verse(raw: str, book: str, chapter: int = 1, verse_no: int = 1) -> str:
    prefix = f"{book} {chapter}:{verse_no}"
    for line in raw.splitlines():
        if line.startswith(prefix):
            return line[len(prefix):]
    raise KeyError(prefix)


def read_book(zf: zipfile.ZipFile, book: str) -> str:
    name = f"SBLGNT-master/data/sblgnt/text/{book}.txt"
    return zf.read(name).decode("utf-8")


def opening_row(zf: zipfile.ZipFile, book: str) -> dict:
    text = verse(read_book(zf, book), book)
    total, jots, _ = score(text, True)
    bare, _, _ = score(text, False)
    composite = 2701 + total
    tri, idx = is_triangular(composite)
    return {
        "book": book,
        "words": word_count(text),
        "jots": jots,
        "total": total,
        "no_jot": bare,
        "plus_2701": composite,
        "closes_t112": tri and idx == 112,
        "text": text.strip(),
    }


def control_table(zip_path: str | Path) -> list[dict]:
    with zipfile.ZipFile(zip_path) as zf:
        return [opening_row(zf, book) for book in BOOKS]


def col_1_17(zip_path: str | Path) -> dict:
    with zipfile.ZipFile(zip_path) as zf:
        text = verse(read_book(zf, "Col"), "Col", 1, 17)
    full, jots, _ = score(text, True)
    bare, _, _ = score(text, False)
    return {"text": text.strip(), "with_jot": full, "no_jot": bare, "jots": jots}


def two_digit_mirror_solutions() -> list[int]:
    found = []
    for a in range(1, 10):
        for b in range(10):
            if 8 * a + 1 == 19 * b:
                found.append(10 * a + b)
    return found
