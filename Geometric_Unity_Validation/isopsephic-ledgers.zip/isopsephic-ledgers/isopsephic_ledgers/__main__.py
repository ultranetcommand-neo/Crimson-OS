"""Replay the 27-opening control against a local SBLGNT zip."""

from __future__ import annotations

import argparse
import urllib.request
from pathlib import Path

from isopsephic_ledgers import col_1_17, control_table, two_digit_mirror_solutions

SBL_URL = "https://github.com/LogosBible/SBLGNT/archive/refs/heads/master.zip"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zip", type=Path, default=Path("sblgnt.zip"))
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    if args.download or not args.zip.exists():
        print(f"downloading {SBL_URL}")
        urllib.request.urlretrieve(SBL_URL, args.zip)

    print("two-digit solutions of n+1 = 2*rev(n):", two_digit_mirror_solutions())
    col = col_1_17(args.zip)
    print(f"Col 1:17 with jot {col['with_jot']}  no jot {col['no_jot']}  jots {col['jots']}")
    print(f"{'book':8} {'words':5} {'jots':4} {'sum':6} {'+2701':7} {'T112'}")
    hits = []
    for row in control_table(args.zip):
        flag = "YES" if row["closes_t112"] else ""
        print(f"{row['book']:8} {row['words']:5} {row['jots']:4} {row['total']:6} {row['plus_2701']:7} {flag}")
        if row["total"] == 3627:
            hits.append(row["book"])
    print("hits at 3627:", hits)


if __name__ == "__main__":
    main()
