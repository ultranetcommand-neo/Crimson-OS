# Isopsephic ledgers

Replay of the October 2026 control. Edition: SBL Greek New Testament, Michael W. Holmes, 2010. Iota subscript counts as 10. Accents and editorial sigla are stripped. Movable nu is kept when printed.

```
pip install -e .
isopsephic-ledgers --download
```

Expected: John 1:1 = 3627, 2701 + 3627 = 6328 = T_112, and no other opening hits 3627. Colossians 1:17 = 6666 with the jot, 6656 without it. The only two-digit solution of n + 1 = 2·rev(n) is 73.
